$(document).ready(function() {
    $('.owl-2').owlCarousel({
        rewind: true,
        margin: 10,
        responsiveClass: true,
        nav: false,
        dots: false,
        autoplay: true,
        slideBy: 3,
        autoplayTimeout: 3000,
        autoplaySpeed: 150,
        responsive: {
            0: {
                items: 1,
                loop: true
            },
            600: {
                items: 2,
                loop: true
            },
            1000: {
                items: 3,
                loop: true
            }
        }
    })
    $('.owl-1').owlCarousel({
        rewind: true,
        margin: 10,
        responsiveClass: true,
        nav: false,
        autoplay: false,
        dotsSpeed: 150,
        // slideTransition: "linear",
        slideBy: 3,
        autoplayTimeout: 3000,
        autoplaySpeed: 3,
        responsive: {
            0: {
                items: 1,
                loop: true
            },
            600: {
                items: 2,
                loop: true
            },
            1000: {
                items: 3,
                margin: 20,
                loop: true
            }
        }
    })
})